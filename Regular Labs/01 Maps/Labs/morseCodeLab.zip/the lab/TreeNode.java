// don't modify

public class TreeNode
{
  public TreeNode(Object initValue, TreeNode initLeft, TreeNode initRight) { 
    value = initValue; 
    left = initLeft; 
    right = initRight; 
  }
  public TreeNode(Object initValue){
  	value = initValue;
  	left = right = null;
  }
  public Object getValue() { return value; }
  public TreeNode getLeft() { return left; }
  public TreeNode getRight() { return right; }
  public void setValue(Object theNewValue) { value = theNewValue; }
  public void setLeft(TreeNode theNewLeft) { left = theNewLeft; }
  public void setRight(TreeNode theNewRight) { right = theNewRight; }

  private Object value;
  private TreeNode left;
  private TreeNode right;
} 